import Link from "next/link"
import { ChevronLeft, ExternalLink } from "lucide-react"
import { dsaTopics, getTopicById, getQuestionsByTopicId } from "@/lib/data"
import { notFound } from "next/navigation"

export function generateStaticParams() {
  return dsaTopics.map((topic) => ({
    topicId: topic.id,
  }))
}

export default function TopicPage({ params }: { params: { topicId: string } }) {
  const topic = getTopicById(params.topicId)

  if (!topic) {
    notFound()
  }

  const questions = getQuestionsByTopicId(params.topicId)

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <header className="border-b bg-white shadow-sm dark:bg-slate-900 dark:border-slate-800">
        <div className="container mx-auto px-4 py-4">
          <Link
            href="/"
            className="inline-flex items-center text-sm font-medium text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Topics
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <div className={`p-2 rounded-lg ${topic.colorClass} mr-4`}>
              <topic.icon className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">{topic.name}</h1>
          </div>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-3xl">{topic.description}</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg shadow dark:bg-slate-800 dark:border-slate-700 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 dark:bg-slate-900 dark:border-slate-700">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">{questions.length} Questions</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 dark:bg-slate-900">
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">#</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Question
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Problem
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Solution
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Completed
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {questions.map((question, index) => (
                  <tr key={index} className="hover:bg-slate-50 dark:hover:bg-slate-700">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-100 text-xs font-medium text-emerald-800 dark:bg-emerald-900 dark:text-emerald-300">
                        {index + 1}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-slate-900 dark:text-white">{question.title}</p>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <Link
                        href={question.problemLink}
                        className="inline-flex items-center text-sm text-emerald-600 hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300"
                      >
                        Problem <ExternalLink className="ml-1 h-3 w-3" />
                      </Link>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <Link
                        href={question.solutionLink}
                        className="inline-flex items-center text-sm text-emerald-600 hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300"
                      >
                        Solution <ExternalLink className="ml-1 h-3 w-3" />
                      </Link>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <input
                        type="checkbox"
                        className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:ring-offset-slate-800"
                        defaultChecked={question.completed}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-8 dark:bg-slate-900 dark:border-slate-800">
        <div className="container mx-auto px-4 text-center text-slate-600 dark:text-slate-400">
          <p>© {new Date().getFullYear()} CodeStudioDSA. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

