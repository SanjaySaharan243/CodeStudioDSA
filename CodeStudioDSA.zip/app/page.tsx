import { Search } from "lucide-react"
import Link from "next/link"
import { dsaTopics } from "@/lib/data"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <header className="border-b bg-white shadow-sm dark:bg-slate-900 dark:border-slate-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-slate-900 dark:text-white">
            CodeStudio<span className="text-emerald-500">DSA</span>
          </Link>
          <div className="relative w-full max-w-md mx-4">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="search"
              className="block w-full p-2 pl-10 text-sm border rounded-lg bg-slate-50 border-slate-300 focus:ring-emerald-500 focus:border-emerald-500 dark:bg-slate-800 dark:border-slate-700 dark:placeholder-slate-400 dark:text-white"
              placeholder="Search for a question or topic..."
            />
          </div>
          <button className="px-4 py-2 text-sm font-medium text-white bg-emerald-500 rounded-lg hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-300">
            Sign In
          </button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <section className="mb-12 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl mb-4">
            Master Data Structures & Algorithms
          </h1>
          <p className="max-w-2xl mx-auto text-xl text-slate-600 dark:text-slate-400">
            A curated collection of important DSA questions to help you ace your coding interviews.
          </p>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dsaTopics.map((topic) => (
            <Link
              key={topic.id}
              href={`/topics/${topic.id}`}
              className="group block p-6 bg-white border border-slate-200 rounded-lg shadow hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:hover:bg-slate-700 transition-all"
            >
              <div className="flex items-center mb-4">
                <div className={`p-2 rounded-lg ${topic.colorClass} mr-4`}>
                  <topic.icon className="h-6 w-6 text-white" />
                </div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">{topic.name}</h2>
              </div>
              <p className="text-slate-600 dark:text-slate-400 mb-4">{topic.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  {topic.questionCount} questions
                </span>
                <span className="text-emerald-500 group-hover:translate-x-1 transition-transform duration-200">→</span>
              </div>
            </Link>
          ))}
        </section>
      </main>

      <footer className="bg-white border-t border-slate-200 py-8 dark:bg-slate-900 dark:border-slate-800">
        <div className="container mx-auto px-4 text-center text-slate-600 dark:text-slate-400">
          <p>© {new Date().getFullYear()} CodeStudioDSA. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

