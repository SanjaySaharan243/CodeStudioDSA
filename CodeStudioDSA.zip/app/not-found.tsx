import Link from "next/link"

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 px-4 dark:bg-slate-900">
      <h1 className="text-6xl font-bold text-slate-900 dark:text-white mb-4">404</h1>
      <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-300 mb-6">Topic Not Found</h2>
      <p className="text-slate-600 dark:text-slate-400 mb-8 text-center max-w-md">
        The topic you're looking for doesn't exist or has been moved.
      </p>
      <Link
        href="/"
        className="px-4 py-2 text-sm font-medium text-white bg-emerald-500 rounded-lg hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-300"
      >
        Return to Home
      </Link>
    </div>
  )
}

